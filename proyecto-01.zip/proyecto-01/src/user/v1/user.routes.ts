import { Router, Request, Response } from "express";
import { createUser, readUsers, loginUser, updateUser, deleteUser, getUserReservations } from "./user.controller";
import { CreateUserType, UpdateUserType } from "./user.types";
import { AuthMiddleware } from "../../middleware/auth";
import { UserType } from "./user.model";

// INIT ROUTES
const userRoutes = Router();

// Función para validar el formato de correo
const isValidEmail = (email: string): boolean => {
    const emailRegex = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return emailRegex.test(email);
};

// DECLARE ENDPOINT FUNCTIONS
async function GetUsers(request: Request, response: Response) {
    const users = await readUsers();
    response.status(200).json({
        message: "Success",
        users: users,
    });
}

async function CreateUser(request: Request, response: Response) {
    // Validación de campos requeridos
    const { name, cedula, email, password } = request.body;
    if (!name || !cedula || !email || !password) {
        return response.status(400).json({ message: "Todos los campos son obligatorios." });
    }

    // Validación de formato de correo
    if (!isValidEmail(email)) {
        return response.status(400).json({ message: "El formato del correo es inválido." });
    }

    try {
        const {user, token} = await createUser(request.body as CreateUserType);
        response.status(201).json({
            message: "Usuario creado exitosamente",
            user,
            token,
        });
    } catch (error) {
        response.status(500).json({
            message: "Error al crear el usuario",
            error: (error as Error).message,
        });
    }
}

async function LoginUser(request: Request, response: Response) {
  const { email, password } = request.body;
  if (!email || !password) {
      return response.status(400).json({ message: "Email y contraseña son obligatorios." });
  }

  if (!isValidEmail(email)) {
      return response.status(400).json({ message: "El formato del correo es inválido." });
  }

  try {
      const user = await loginUser(email, password);
      if (user) {
          response.status(200).json({
              message: "Inicio de sesión exitoso",
              user,
          });
      } else {
          response.status(401).json({ message: "Credenciales incorrectas." });
      }
  } catch (error) {
      response.status(500).json({
          message: "Error en el inicio de sesión",
          error: (error as Error).message,
      });
  }
}

async function UpdateUser(request: Request, response: Response) {
  const userId = request.params.id;
  const updateData: UpdateUserType = request.body;
  const requestingUser = request.user;

  if (!requestingUser) {
      return response.status(401).json({ message: "User not authenticated." });
  }

  try {
      const updatedUser = await updateUser(userId, updateData, requestingUser);
      if (updatedUser) {
          response.status(200).json({
              message: "Usuario actualizado exitosamente",
              user: updatedUser,
          });
      } else {
          response.status(404).json({ message: "Usuario no encontrado." });
      }
  } catch (error) {
      response.status(403).json({
          message: "No tienes permiso para modificar este usuario.",
          error: (error as Error).message,
      });
  }
}

async function DeleteUser(request: Request, response: Response) {
    const userId = request.params.id;
    const requestingUser = request.user;

    if (!requestingUser) {
        return response.status(401).json({ message: "User not authenticated." });
    }

    try {
        const deletedUser = await deleteUser(userId, requestingUser);
        if (deletedUser) {
            response.status(200).json({
                message: "Usuario inhabilitado exitosamente",
                user: deletedUser,
            });
        } else {
            response.status(404).json({ message: "Usuario no encontrado." });
        }
    } catch (error) {
        response.status(403).json({
            message: "No tienes permiso para inhabilitar este usuario.",
            error: (error as Error).message,
        });
    }
}

async function GetUserReservations(request: Request, response: Response) {
    const requestingUser = request.user;

    if (!requestingUser) {
        return response.status(401).json({ message: "User not authenticated." });
    }

    try {
        const reservations = await getUserReservations(requestingUser._id);
        response.status(200).json({
            message: "Reservas obtenidas exitosamente",
            reservations: reservations,
        });
    } catch (error) {
        response.status(500).json({
            message: "Error al obtener las reservas del usuario",
            error: (error as Error).message,
        });
    }
}


// DECLARE ENDPOINTS
userRoutes.get("/reservations", AuthMiddleware, GetUserReservations);
userRoutes.post("/", CreateUser);
userRoutes.post("/login", LoginUser);
userRoutes.put("/:id", AuthMiddleware, UpdateUser);
userRoutes.delete("/:id", AuthMiddleware, DeleteUser);

// EXPORT ROUTES
export default userRoutes;
