import { UserModel, UserType } from "./user.model";
import { CreateUserType } from "./user.types";
import jwt from "jsonwebtoken";
import { env } from "process";

// DECLARE ACTION FUNCTION
async function createUserAction(userData: CreateUserType): Promise<{ user: UserType; token: string }> {
    const user = await UserModel.create(userData);

    // Generar el token JWT usando el ID del usuario y la clave secreta
    const token = jwt.sign({ id: user._id }, (env as { JWT_SECRET: string }).JWT_SECRET);
    return { user, token };
}

// EXPORT ACTION FUNCTION
export default createUserAction;

