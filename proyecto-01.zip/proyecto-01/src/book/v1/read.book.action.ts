import mongoose from "mongoose";
import { BookModel, BookType } from "./book.model";

// Función para buscar un libro por ID con validación y limpieza
async function findBookById(bookId: string): Promise<BookType | null> {
    // Limpiar el bookId de espacios o saltos de linea
    bookId = bookId.trim();

    // Verificar que bookId es un ObjectId válido
    if (!mongoose.Types.ObjectId.isValid(bookId)) {
        throw new Error("ID de libro no válido.");
    }

    return await BookModel.findById(bookId);
}

async function findBooksByFilters(filters: Partial<BookType>): Promise<BookType[]> {
    const query: any = {
        isAvailable: true
    };

    if (filters.genre) query.genre = { $regex: filters.genre, $options: "i" };
    if (filters.publishingHouse) query.publishingHouse = { $regex: filters.publishingHouse, $options: "i" };
    if (filters.author) query.author = { $regex: filters.author, $options: "i" };
    if (filters.name) query.name = { $regex: filters.name, $options: "i" };


    if (filters.publicationDate) {
        const startOfDay = new Date(filters.publicationDate);
        startOfDay.setHours(0, 0, 0, 0);
        const endOfDay = new Date(filters.publicationDate);
        endOfDay.setHours(23, 59, 59, 999);

        query.publicationDate = { $gte: startOfDay, $lte: endOfDay };
    }


    return await BookModel.find(query);
}

export { findBookById, findBooksByFilters };
