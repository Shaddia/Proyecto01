import createBookAction from "./create.book.action";
import { findBookById, findBooksByFilters } from "./read.book.action";
import updateBookAction from "./update.book.action";
import deleteBookAction from "./delete.book.action";
import { BookType } from "./book.model";
import { RequestingUserType } from "../../user/v1/user.types";

// Controlador para crear un libro, verificando permisos
async function createBook(bookData: BookType, requestingUser: RequestingUserType): Promise<BookType> {
    if (!requestingUser.permissions.canCreateBooks) {
        throw new Error("No tienes permiso para crear libros.");
    }
    return await createBookAction(bookData);
}

async function readBooks(bookId: string | null, filters: Partial<BookType>): Promise<BookType | BookType[] | null> {
    if (bookId) {
        return await findBookById(bookId);
    } else {
        return await findBooksByFilters(filters);
    }
}

async function updateBook(bookId: string, updateData: Partial<BookType>, requestingUser: RequestingUserType): Promise<BookType | null> {
    if (!requestingUser.permissions.canModifyBooks) {
        throw new Error("No tienes permiso para modificar libros.");
    }
    return await updateBookAction(bookId, updateData);
}

async function deleteBook(bookId: string, requestingUser: RequestingUserType): Promise<BookType | null> {
    if (!requestingUser.permissions.canDisableBooks) {
        throw new Error("No tienes permiso para inhabilitar libros.");
    }
    return await deleteBookAction(bookId);
}

export { createBook, readBooks, updateBook, deleteBook };
